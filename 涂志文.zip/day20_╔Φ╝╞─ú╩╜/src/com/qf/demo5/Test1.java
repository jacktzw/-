package com.qf.demo5;

import java.io.File;
import java.io.IOException;
import java.util.Date;

public class Test1 {
    public static void main(String[] args) throws IOException {
        /*System.out.println(System.getProperty("user.dir"));
        File file=new File("d:/aaa/a.txt");
        boolean mkdir = file.mkdirs();
        System.out.println(mkdir);
        System.out.println(file.getParentFile());
        TicketWin win1=new TicketWin("窗口一");
        TicketWin win2=new TicketWin("窗口二");
        TicketWin win3=new TicketWin("窗口三");
        TicketWin win4=new TicketWin("窗口四");
        win1.start();
        win2.start();
        win3.start();
        win4.start();*/

    }
}
