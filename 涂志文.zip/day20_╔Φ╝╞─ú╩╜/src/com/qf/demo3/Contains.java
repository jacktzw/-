package com.qf.demo3;

/**
 * @author : 14118
 * @version : V1.0
 * @packageName :  com.qf.demo3
 * @created : 2020/8/14
 * @description :
 */
public class Contains {
    public final static int ZHUO_SHAO=1;
    public final static int BING_DONG=2;
    public final static int ZHONG_DU=3;
}
